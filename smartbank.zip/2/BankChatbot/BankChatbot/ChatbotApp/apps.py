from django.apps import AppConfig


class ChatbotappConfig(AppConfig):
    name = 'ChatbotApp'
